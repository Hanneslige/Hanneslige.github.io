## Hosting

The page is hosted [here](https://Hanneslige.github.io).

## Audit

Questions can be found [here](https://github.com/01-edu/public/tree/master/subjects/graphql/audit).


## Developer
- hannes878